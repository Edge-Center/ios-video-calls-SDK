#import <Foundation/Foundation.h>

//! Project version number for EdgeCenterVideoCallsSDK.
FOUNDATION_EXPORT double EdgeCenterVideoCallsSDKVersionNumber;

//! Project version string for EdgeCenterVideoCallsSDK.
FOUNDATION_EXPORT const unsigned char EdgeCenterVideoCallsSDKVersionString[];
